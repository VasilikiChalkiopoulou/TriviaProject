module TriviaProject {
	exports exception;
	exports service;
	exports TriviaProject;

	requires com.fasterxml.jackson.annotation;
	requires com.fasterxml.jackson.core;
	requires com.fasterxml.jackson.databind;
	requires org.apache.httpcomponents.httpclient;
	requires org.apache.httpcomponents.httpcore;
	
	opens service to com.fasterxml.jackson.databind;
	opens TriviaProject to com.fasterxml.jackson.databind;
}