package service;

import java.io.IOException;
/*import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.fasterxml.jackson.databind.ObjectMapper;

import exception.MovieAPIException;
import model.MovieInfo;
import model.themoviedb.ErrorResponse;
import model.themoviedb.Movie;
import model.themoviedb.MovieResult;*/
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import com.fasterxml.jackson.core.type.TypeReference;


import com.fasterxml.jackson.databind.ObjectMapper;

import TriviaProject.ErrorResponse;
import TriviaProject.TriviaQuestion;
import TriviaProject.TriviaResponse;
import exception.TriviaAPIException;
import TriviaProject.TriviaCategoryResponse;
import TriviaProject.TriviaCategory;
import java.io.IOException;

// Επικοινωνία με το API
public class TriviaAPIService {

	private final String API_URL;

	// Βάση του API URL
	public TriviaAPIService(String API_URL) {
		this.API_URL = API_URL;
	}
	
	public TriviaAPIService() {
	    this.API_URL = "https://opentdb.com/api.php";
	}

	
	public List<TriviaQuestion> getTriviaQuestions(int amount, String category, String difficulty, String type) throws TriviaAPIException{
		List<TriviaQuestion> TriviaInfoList= new ArrayList<TriviaQuestion>();
		try {
			
			// Δημιουργία του URIBuilder για να προσθέσουμε τις παραμέτρους στην κλήση API.
			URIBuilder uriBuilder = new URIBuilder(API_URL)
					.addParameter("amount", String.valueOf(amount));

			if (category != null && !category.isEmpty()) {
				uriBuilder.addParameter("category", category);
			}

			if (difficulty != null && !difficulty.isEmpty()) {
				uriBuilder.addParameter("difficulty", difficulty);
			}

			if (type != null && !type.isEmpty()) {
				uriBuilder.addParameter("type", type);
			}
			
			// Μετατροπή του URIBuilder σε URI.
			URI uri = uriBuilder.build();
			
			// Δημιουργία HTTP GET αιτήματος.
			HttpGet getRequest = new HttpGet(uri);
			CloseableHttpClient httpclient = HttpClients.createDefault();
			
			// Εκτέλεση του HTTP αιτήματος.
			CloseableHttpResponse response = httpclient.execute(getRequest);
			
			HttpEntity entity = response.getEntity();
			
			// Ανάλυση της απάντησης μέσω Jackson ObjectMapper.
			ObjectMapper mapper = new ObjectMapper();
			
			// Έλεγχος για σφάλματα από το API.
			if (response.getStatusLine().getStatusCode()!=HttpStatus.SC_OK) {
				ErrorResponse errorResponse= mapper.readValue(entity.getContent(), ErrorResponse.class);
				if (errorResponse.getStatusCode()!=null) {
					System.out.println(errorResponse.getStatusCode());
					throw new TriviaAPIException("Error occured on API call"+ errorResponse.getStatusMessage());
				}
			}
			
			
			// Μετατροπή της απάντησης JSON σε αντικείμενα TriviaResponse.
			TriviaResponse generatedTriviaResultObject = mapper.readValue(entity.getContent(), TriviaResponse.class);
			
			List<TriviaQuestion> mResults= generatedTriviaResultObject.getResults();
			
			// Επεξεργασία των ερωτήσεων.
			for (TriviaQuestion r: mResults) {
				TriviaQuestion m= new TriviaQuestion(r.getCategory(), r.getType(), r.getDifficulty(), r.getQuestion(), r.getCorrectAnswer(), r.getIncorrectAnswers());
				TriviaInfoList.add(m);
				System.out.println("Category: "+m.getCategory()+"\nType: "+m.getType()+"\nDifficulty: "+m.getDifficulty()+"\nQuestion: "+r.getQuestion()+"\nCorrectAnswer: "+r.getCorrectAnswer()+"\ngIncorrectAnswers: "+r.getIncorrectAnswers());
			}
			
		} catch (UnknownHostException e) {
		    throw new TriviaAPIException("Cannot connect to the Trivia API. Please check your internet connection or the API URL.", e);
		} catch (URISyntaxException e) {
		    throw new TriviaAPIException("Problem with UI", e);
		} catch (ClientProtocolException e) {
		    throw new TriviaAPIException("Problem with Client Protocol", e);
		} catch (IOException e) {
		    throw new TriviaAPIException("Error requesting data from Trivia API", e);
		}

		return TriviaInfoList;
	
	
	}
	
	
	//Ανάκτηση λίστας κατηγοριών από το Trivia API.
	public Map<String, String> getTriviaCategories() throws TriviaAPIException {
	    Map<String, String> categoryMap = new HashMap<>();
	    try {
	    	// Δημιουργία του URI για την κλήση των κατηγοριών.
	        URI uri = new URI("https://opentdb.com/api_category.php");
	        
	        // Δημιουργία HTTP GET αιτήματος.
	        HttpGet getRequest = new HttpGet(uri);
	        CloseableHttpClient httpClient = HttpClients.createDefault();
	        
	        // Εκτέλεση του HTTP αιτήματος.
	        CloseableHttpResponse response = httpClient.execute(getRequest);

	        // Ανάλυση της απάντησης μέσω Jackson ObjectMapper.
	        ObjectMapper mapper = new ObjectMapper();
	        TriviaCategoryResponse categoryResponse = mapper.readValue(
	        	    response.getEntity().getContent(),
	        	    new TypeReference<TriviaCategoryResponse>() {}
	        	);

	        // Προσθήκη κατηγοριών στον HashMap.
	        for (TriviaCategory category : categoryResponse.getTriviaCategories()) {
	            categoryMap.put(category.getName(), String.valueOf(category.getId())); // Όνομα -> ID
	        }
	    } catch (Exception e) {
	        throw new TriviaAPIException("Error retrieving trivia categories", e);
	    }
	    return categoryMap;
	}

}
