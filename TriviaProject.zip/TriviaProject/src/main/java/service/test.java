package service;

import exception.TriviaAPIException;


//Δοκιμαστική μέθοδος main για την κλήση του API
public class test {
	public static void main(String[] args) {
		TriviaAPIService mas=new TriviaAPIService("https://opentdb.com/api.php");
		try {
			int amount = 10;
			String category = "12";
			String difficulty = "easy";
			String type = "multiple";
			mas.getTriviaQuestions(amount, category, difficulty, type);
		}catch(TriviaAPIException e) {
		    e.printStackTrace();  // Εμφανίζει μήνυμα λάθους
		}

	}
}
