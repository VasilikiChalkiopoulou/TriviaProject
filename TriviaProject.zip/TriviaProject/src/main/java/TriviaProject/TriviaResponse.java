package TriviaProject;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


//Η απάντηση από το API
public class TriviaResponse {
	
	/** 
     * 0 - Success
     * 1 - No Results
     * 2 - Invalid Parameter
     * 3 - Token Not Found
     * 4 - Token Empty
     */
	@JsonProperty("response_code")
    private int response_code;
	
	// Η λίστα με τις ερωτήσεις που επιστρέφει το API
	@JsonProperty("results")
    private List<TriviaQuestion> results;

    // Getters and Setters
    public int getResponseCode() {
        return response_code;
    }

    public void setResponseCode(int response_code) {
        this.response_code = response_code;
    }

    public List<TriviaQuestion> getResults() {
        return results;
    }

    public void setResults(List<TriviaQuestion> results) {
        this.results = results;
    }
}