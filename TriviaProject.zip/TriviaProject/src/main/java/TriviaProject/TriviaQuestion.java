package TriviaProject;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import com.fasterxml.jackson.annotation.JsonProperty;


//Η κλάση TriviaCategory αναπαριστά μια ερώτηση από το API
public class TriviaQuestion {
    private String category;
    private String type;
    private String difficulty;
    private String question;
    @JsonProperty("correct_answer")
    private String correct_answer;
    @JsonProperty("incorrect_answers")
    private List<String> incorrect_answers;

    
    
    
    public TriviaQuestion() {
		//super();
	}

	public TriviaQuestion(String category, String type, String difficulty, String question, String correct_answer,
			List<String> incorrect_answers) {
		super();
		this.category = category;
		this.type = type;
		this.difficulty = difficulty;
		this.question = question;
		this.correct_answer = correct_answer;
		this.incorrect_answers = incorrect_answers;
	}

	// Getters and Setters
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCorrectAnswer() {
        return correct_answer;
    }

    public void setCorrectAnswer(String correct_answer) {
        this.correct_answer = correct_answer;
    }

    public List<String> getIncorrectAnswers() {
        return incorrect_answers;
    }

    public void setIncorrectAnswers(List<String> incorrect_answers) {
        this.incorrect_answers = incorrect_answers;
    }
    
    //Λίστα με όλες τις πιθανές απαντήσεις σε ανακατεμένη σειρά.
    public List<String> getAllAnswers() {
        List<String> allAnswers = new ArrayList<>(incorrect_answers); //Βάζουμε τις λανθασμένες απαντήσεις
        allAnswers.add(correct_answer); // Προσθέτουμε τη σωστή απάντηση στη λίστα
        Collections.shuffle(allAnswers); // Ανακατεύουμε τις απαντήσεις για τυχαία σειρά
        return allAnswers;
    }
}