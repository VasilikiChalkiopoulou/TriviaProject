package TriviaProject;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

//Αποθήκευση των διαθέσιμων κατηγοριών

public class TriviaCategoryResponse {
	@JsonProperty("trivia_categories")
    private List<TriviaCategory> trivia_categories;

    public List<TriviaCategory> getTriviaCategories() {
        return trivia_categories;
    }

    public void setTriviaCategories(List<TriviaCategory> trivia_categories) {
        this.trivia_categories = trivia_categories;
    }
}
