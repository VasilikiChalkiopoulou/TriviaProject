package testing;


import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import exception.TriviaAPIException;
import TriviaProject.TriviaQuestion;
import service.TriviaAPIService;

public class TriviaAPITest {

//	@Test
//	public void testDiscoverAPI() throws TriviaAPIException {
//		// Δημιουργία αντικειμένου της υπηρεσίας API
//		TriviaAPIService mas=new TriviaAPIService("https://opentdb.com/api.php");
//		
//		// Κλήση της μεθόδου getTriviaQuestions()
//		List<TriviaQuestion> results=mas.getTriviaQuestions(5, "12", "easy", "multiple");
//		
//		// Επαλήθευση ότι η λίστα δεν είναι κενή
//		Assert.assertFalse(results.isEmpty());
//		for (TriviaQuestion m: results) {
//			System.out.println("Category: "+m.getCategory()+"\nType: "+m.getType()+"\nDifficulty: "+m.getDifficulty()+"\nQuestion: "+m.getQuestion()+"\nCorrectAnswer: "+m.getCorrectAnswer()+"\ngIncorrectAnswers: "+m.getIncorrectAnswers());
//		}
//	}
	
//	@Test
//	public void testInvalidAPIUrl() {
//		// Δημιουργία αντικειμένου με λάθος URL
//	    try {
//	        TriviaAPIService mas = new TriviaAPIService("https://wrong-url.com/api.php");
//	        mas.getTriviaQuestions(5, "12", "easy", "multiple");
//	        Assert.fail("Expected TriviaAPIException but none was thrown");
//	    } catch (TriviaAPIException e) {
//	        System.out.println("Caught expected exception: " + e.getMessage());
//	    }
//	}
	
//	@Test
//	public void testInvalidCategory() {
//	    try {
//	        TriviaAPIService mas = new TriviaAPIService();
//			 //Προσπάθεια ανάκτησης ερωτήσεων με άκυρο ID κατηγορίας (999)
//	        List<TriviaQuestion> results = mas.getTriviaQuestions(5, "999", "easy", "multiple"); // Άκυρη κατηγορία
//	        Assert.assertTrue(results.isEmpty()); // Πρέπει να επιστρέψει κενή λίστα
//	    } catch (TriviaAPIException e) {
//			// Αναμένουμε κενή λίστα και όχι exception
//	        Assert.fail("TriviaAPIException was thrown: " + e.getMessage());
//	    }
//	}



}
