package triviaprojectfx.triviaprojectfx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

// Κύρια κλάση της εφαρμογής που ξεκινά το Trivia Game.
public class App extends Application {
	/**
     * Η μέθοδος `start` εκτελείται αυτόματα κατά την εκκίνηση της JavaFX εφαρμογής.
     * Αρχικοποιεί και εμφανίζει το κύριο παράθυρο του παιχνιδιού.
     */
    @Override
    public void start(Stage primaryStage) {
    	// Δημιουργία αντικειμένου MainSceneCreator για την αρχική σκηνή επιλογών.
        MainSceneCreator mainSceneCreator = new MainSceneCreator();
        // Δημιουργία της αρχικής σκηνής χρησιμοποιώντας το αντικείμενο MainSceneCreator.
        Scene mainScene = mainSceneCreator.createMainScene(primaryStage);

        // Ορισμός τίτλου για το παράθυρο της εφαρμογής.
        primaryStage.setTitle("Trivia Game");
        // Ορισμός της αρχικής σκηνής στο παράθυρο.
        primaryStage.setScene(mainScene);
        // Εμφάνιση του παραθύρου στον χρήστη.
        primaryStage.show();
    }

    /**
     * Κύρια μέθοδος της εφαρμογής.
     * Καλεί τη `launch(args)`, η οποία εκκινεί την JavaFX εφαρμογή.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
