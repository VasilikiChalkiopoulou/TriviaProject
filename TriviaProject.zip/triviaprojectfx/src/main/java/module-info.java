module triviaprojectfx {
	exports triviaprojectfx.triviaprojectfx;

	requires TriviaProject;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
}