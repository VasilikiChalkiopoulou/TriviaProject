package triviaprojectfx.triviaprojectfx;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import service.TriviaAPIService;
import exception.TriviaAPIException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Map;


public class MainSceneCreator {
    private final TriviaAPIService triviaService = new TriviaAPIService();
    private Map<String, String> categoryMap; // Αποθήκευση των κατηγοριών (Όνομα -> ID)

    public Scene createMainScene(Stage primaryStage) {
        VBox layout = new VBox(10);

        // Dropdown για τις κατηγορίες
        ComboBox<String> categoryDropdown = new ComboBox<>();
        categoryDropdown.setPromptText("Επιλέξτε Κατηγορία");

        // Dropdown για τη δυσκολία
        ComboBox<String> difficultyDropdown = new ComboBox<>();
        difficultyDropdown.getItems().addAll("easy", "medium", "hard");
        difficultyDropdown.setPromptText("Επιλέξτε Δυσκολία");

        // Dropdown για τον τύπο ερώτησης
        ComboBox<String> typeDropdown = new ComboBox<>();
        typeDropdown.getItems().addAll("multiple", "boolean");
        typeDropdown.setPromptText("Επιλέξτε Τύπο");

        // Πεδίο για τον αριθμό των ερωτήσεων
        TextField amountField = new TextField();
        amountField.setPromptText("Αριθμός ερωτήσεων (1-50)");

        // Κουμπί εκκίνησης του παιχνιδιού
        Button startButton = new Button("Έναρξη Quiz");

        // Γέμισμα του dropdown με τις κατηγορίες από το API
        try {
            categoryMap = triviaService.getTriviaCategories();
            categoryDropdown.getItems().addAll(categoryMap.keySet());
        } catch (TriviaAPIException e) {
            showAlert("Σφάλμα", "Αποτυχία φόρτωσης των κατηγοριών.");
        }

        // Έναρξη του Quiz με έλεγχο των δεδομένων
        startButton.setOnAction(event -> {
            String amountText = amountField.getText();

            // Έλεγχος αν το amount είναι αριθμός
            try {
                int amount = Integer.parseInt(amountText);

                // Έλεγχος αν είναι μεταξύ 1 και 50
                if (amount < 1 || amount > 50) {
                    showAlert("Λάθος!", "Ο αριθμός των ερωτήσεων πρέπει να είναι μεταξύ 1 και 50.");
                    return;
                }

                // Ανάκτηση επιλογών από τα dropdowns
                String selectedCategory = categoryDropdown.getValue();
                String selectedCategoryId = (selectedCategory != null) ? categoryMap.get(selectedCategory) : null;
                String selectedDifficulty = difficultyDropdown.getValue();
                String selectedType = typeDropdown.getValue();

                // Έλεγχος αν έχουν επιλεγεί όλες οι απαραίτητες επιλογές
                if (selectedCategoryId == null || selectedDifficulty == null || selectedType == null) {
                    showAlert("Λάθος!", "Παρακαλώ επιλέξτε όλες τις παραμέτρους του quiz.");
                    return;
                }

                // Δημιουργία αντικειμένου για τη σκηνή του Quiz και έναρξη του παιχνιδιού
                TriviaSceneCreator triviaSceneCreator = new TriviaSceneCreator(triviaService);
                triviaSceneCreator.startQuiz(primaryStage, amount, selectedCategoryId, selectedDifficulty, selectedType);

            } catch (NumberFormatException e) {
                showAlert("Λάθος!", "Παρακαλώ εισάγετε έναν αριθμό από 1 έως 50.");
            }
        });

        // Προσθήκη των στοιχείων στο layout
        layout.getChildren().addAll(categoryDropdown, difficultyDropdown, typeDropdown, amountField, startButton);
        // Επιστροφή μιας νέας σκηνής με το layout
        return new Scene(layout, 400, 300);
    }

    // Μέθοδος εμφάνισης alert
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
