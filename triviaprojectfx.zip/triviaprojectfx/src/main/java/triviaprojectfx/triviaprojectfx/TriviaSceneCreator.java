package triviaprojectfx.triviaprojectfx;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import service.TriviaAPIService;
import TriviaProject.TriviaQuestion;
import exception.TriviaAPIException;
import java.util.List;

// Κλάση Υπεύθυνη για την εμφάνιση των ερωτήσεων
public class TriviaSceneCreator {
    private final TriviaAPIService triviaService; // Αντικείμενο για την επικοινωνία με το API
    private int currentQuestionIndex = 0; // Δείκτης για την τρέχουσα ερώτηση
    private List<TriviaQuestion> questions; // Λίστα με τις ερωτήσεις του κουίζ
    private int score = 0; // Σκορ
    private static int maxScore = 0; // Διατήρηση μέγιστου σκορ
    private int correctanswers = 0;

    public TriviaSceneCreator(TriviaAPIService triviaService) {
        this.triviaService = triviaService;
    }

    // Προσθήκη μεταβλητών για αποθήκευση των τελευταίων ρυθμίσεων
    private static String lastCategory = "";
    private static String lastDifficulty = "";
    private static String lastType = "";
    private static int lastAmount = 0;
    /**
     * Ξεκινά το κουίζ ανακτώντας τις ερωτήσεις από το API και εμφανίζοντας την πρώτη ερώτηση.
     * primaryStage Το βασικό παράθυρο (stage) της εφαρμογής.
     */
    public void startQuiz(Stage primaryStage, int amount, String category, String difficulty, String type) {
    	try {
            // Αν αλλάξει κάποια ρύθμιση, μηδενίζουμε το maxScore
            if (!category.equals(lastCategory) || !difficulty.equals(lastDifficulty) || 
                !type.equals(lastType) || amount != lastAmount) {
                maxScore = 0;
            }

            // Ενημέρωση των τελευταίων επιλογών
            lastCategory = category;
            lastDifficulty = difficulty;
            lastType = type;
            lastAmount = amount;

            // Ανάκτηση ερωτήσεων
            questions = triviaService.getTriviaQuestions(amount, category, difficulty, type);
            showQuestion(primaryStage);
        } catch (TriviaAPIException e) {
            showAlert("Σφάλμα", "Αποτυχία φόρτωσης των ερωτήσεων.");
        }
    }

    // Εμφανίζει την τρέχουσα ερώτηση στον χρήστη.
    private void showQuestion(Stage primaryStage) {
    	// Αν έχουν απαντηθεί όλες οι ερωτήσεις, εμφανίζει το τελικό σκορ.
        if (currentQuestionIndex >= questions.size()) {
            showFinalScore(primaryStage);
            return;
        }

        // Ανάκτηση της τρέχουσας ερώτησης από τη λίστα
        TriviaQuestion question = questions.get(currentQuestionIndex);
        // Δημιουργία ενός κάθετου πλαισίου (VBox) με απόσταση 10 pixels μεταξύ των στοιχείων
        VBox layout = new VBox(10);
        // Ετικέτα που εμφανίζει το κείμενο της ερώτησης
        Label questionLabel = new Label(question.getQuestion());
        // Δημιουργία μιας ομάδας επιλογών (ToggleGroup) ώστε ο χρήστης να μπορεί να επιλέξει μόνο μία απάντηση
        ToggleGroup answerGroup = new ToggleGroup();
        // Δημιουργία ενός κάθετου πλαισίου (VBox) για την τοποθέτηση των απαντήσεων
        VBox answerBox = new VBox(5);

        // Χρήση της μεθόδου getAllAnswers() για την ανάκτηση των απαντήσεων
        List<String> allAnswers = question.getAllAnswers();

        // Προσθήκη των απαντήσεων ως RadioButton
        for (String answer : allAnswers) {
            RadioButton answerButton = new RadioButton(answer);
            answerButton.setToggleGroup(answerGroup);
            answerBox.getChildren().add(answerButton);
        }

        // Κουμπί υποβολής της απάντησης
        Button submitButton = new Button("Υποβολή");
        submitButton.setOnAction(e -> {
            RadioButton selectedButton = (RadioButton) answerGroup.getSelectedToggle();
            // Ελέγχει αν η απάντηση είναι σωστή ή λάθος
            if (selectedButton != null) {
                checkAnswer(primaryStage, selectedButton.getText(), question.getCorrectAnswer());
            } else {
            	// Αν δεν έχει επιλεγεί απάντηση, εμφανίζει προειδοποίηση
                showAlert("Προσοχή!", "Παρακαλώ επιλέξτε μια απάντηση.");
            }
        });

        // Προσθήκη των στοιχείων στη σκηνή και εμφάνισή της
        layout.getChildren().addAll(questionLabel, answerBox, submitButton);
        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void checkAnswer(Stage primaryStage, String selectedAnswer, String correctAnswer) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if (selectedAnswer.equals(correctAnswer)) {
            alert.setTitle("Σωστή απάντηση!");
            alert.setHeaderText(null);
            alert.setContentText("Σωστά! Κερδίζετε 10 πόντους.");
            score += 10; // Προσθήκη 10 πόντων για σωστή απάντηση
            correctanswers += 1;
        } else {
            alert.setTitle("Λάθος απάντηση!");
            alert.setHeaderText(null);
            alert.setContentText("Λάθος! Η σωστή απάντηση ήταν: " + correctAnswer + ". Χάνετε 5 πόντους.");
            score -= 5; // Αφαίρεση 5 πόντων για λάθος απάντηση
        }
        alert.showAndWait();

        // Μετάβαση στην επόμενη ερώτηση
        currentQuestionIndex++;
        showQuestion(primaryStage);
    }

    // Εμφανίζει το τελικό σκορ του χρήστη και αν είναι νέο ρεκόρ.
    private void showFinalScore(Stage primaryStage) {

    	if (score < 0) {
    		score = 0;
    	}
    	
    	double successRate = ((double) correctanswers / questions.size() ) * 100;
    	String message = "Τελικό σκορ: " + score + "\nΠοσοστό επιτυχίας: " + String.format("%.2f", successRate) + "%";

        // Έλεγχος αν ο παίκτης έκανε νέο ρεκόρ
        if (score > maxScore) {
            maxScore = score;
            message += "\n Νέο ρεκόρ!";
        }

        // Προσθήκη εμφάνισης του μέγιστου σκορ
        message += "\nΜέγιστο σκορ: " + maxScore;

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Quiz Ολοκληρώθηκε!");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();

        // Επαναφορά του παιχνιδιού
        resetGame(primaryStage);
    }

    // Επαναφέρει το παιχνίδι και επιστρέφει στην αρχική σκηνή.
    private void resetGame(Stage primaryStage) {
        currentQuestionIndex = 0;
        score = 0;
        MainSceneCreator mainSceneCreator = new MainSceneCreator();
        primaryStage.setScene(mainSceneCreator.createMainScene(primaryStage));
    }

    // Εμφανίζει ένα μήνυμα προειδοποίησης ή σφάλματος στον χρήστη.
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
